package DEMOAPPLICATION;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class DEMOAPPLICATION extends JFrame{
	JComboBox jc= new JComboBox();
		JPanel panel=new JPanel();
	Connection conn = null;
	Statement stmt = null; 
	ResultSet rs = null;
	

	public DEMOAPPLICATION (){
	   this.setSize(400, 400);
	   this.setLocationRelativeTo(null);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		try {
		    conn =
		       DriverManager.getConnection("jdbc:mysql://localhost/Basketball?" +
		                                   "user=avinash&password=avinash&autoReconnect=true&useSSL=false");
		    // Do something with the Connection
		    stmt = conn.createStatement();
		    String s = "SELECT * from emloyee";
		    rs = stmt.executeQuery(s);
		   String temp="";
		   
		    while(rs.next()){
		   
		    //jc.addItem(rs.getInt(2));
		    temp+=rs.getString(2);
		    
		    } 
			}
                catch (Exception e) {
			    // handle any errors
			  JOptionPane.showMessageDialog(null,"ERROR");
			  }
			finally {
			   try{
				   stmt.close();
				   rs.close();
				   conn.close();
			   }catch (Exception e) {
				    // handle any errors
				  JOptionPane.showMessageDialog(null,"ERROR CLOSE");
				  }
			} 
				   panel.add(jc);
				   this.getContentPane().add(panel);
				   this.setVisible(true);
	
        }		   
	public static void main(String[] args) {
	new  DEMOAPPLICATION();
	}
}
