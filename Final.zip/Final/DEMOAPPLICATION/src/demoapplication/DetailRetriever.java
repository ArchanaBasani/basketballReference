/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package demoapplication;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Rust
 */
public class DetailRetriever {

    public static String getDetails12() {

        try {
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/nba_database?" + "user=avinash&password=avinash&autoReconnect=true&useSSL=false");
            // Do something with the Connection
            Statement stmt = conn.createStatement();
            String s = "SELECT * from team";
            ResultSet rs = stmt.executeQuery(s);
            String temp = "SelectTeam;";

            while (rs.next()) {

                //jc.addItem(rs.getInt(2));
                temp += rs.getString(1) + ";";

            }

            return temp;
        } catch (SQLException ex) {
            Logger.getLogger(DetailRetriever.class.getName()).log(Level.SEVERE, null, ex);
        }
        return " ";
    }

    public static String getDetails1() {

        try {
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/nba_database?" + "user=avinash&password=avinash&autoReconnect=true&useSSL=false");
            // Do something with the Connection
            Statement stmt = conn.createStatement();
            String s = "SELECT*from played_in";
            ResultSet rs = stmt.executeQuery(s);
            String temp = "SelectPlayer;";

            while (rs.next()) {

                //jc.addItem(rs.getInt(2));
                temp += rs.getString(2) + ";";

            }

            return temp;
        } catch (SQLException ex) {
            Logger.getLogger(DetailRetriever.class.getName()).log(Level.SEVERE, null, ex);
        }
        return " ";
    }
 public static String getDetails3(String GAME_ID) {

        try {
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/nba_database?" + "user=avinash&password=avinash&autoReconnect=true&useSSL=false");
            // Do something with the Connection
            Statement stmt = conn.createStatement();
            String s = "SELECT  * from played_in where played_in.GAME_ID=" + GAME_ID;
            ResultSet rs = stmt.executeQuery(s);
            String temp = "";

            int columnCount = 25;

            while (rs.next()) {

                //jc.addItem(rs.getInt(2));
                String[] values = new String[columnCount];
                for (int i = 1; i <= columnCount; i++) {
                    values[i - 1] = rs.getString(i) + "#";
                };
                StringBuilder strBuilder = new StringBuilder();
                for (int i = 0; i < values.length; i++) {
                    strBuilder.append(values[i]);
                }
                temp = temp+strBuilder.toString();

            }

            return temp;
        } catch (SQLException ex) {
            Logger.getLogger(DetailRetriever.class.getName()).log(Level.SEVERE, null, ex);
        }
        return " ";

    }

    public static String getDetails2(String teamname) {

        try {
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/nba_database?" + "user=avinash&password=avinash&autoReconnect=true&useSSL=false");
            // Do something with the Connection
            Statement stmt = conn.createStatement();
            String s = "SELECT  * from team where Team='" + teamname+"'";
            ResultSet rs = stmt.executeQuery(s);
            String temp = "";

            int columnCount = 15;

            while (rs.next()) {

                //jc.addItem(rs.getInt(2));
                String[] values = new String[columnCount];
                for (int i = 1; i <= columnCount; i++) {
                    values[i - 1] = rs.getString(i) + "#";
                };
                StringBuilder strBuilder = new StringBuilder();
                for (int i = 0; i < values.length; i++) {
                    strBuilder.append(values[i]);
                }
                temp = temp+strBuilder.toString();

            }

            return temp;
        } catch (SQLException ex) {
            Logger.getLogger(DetailRetriever.class.getName()).log(Level.SEVERE, null, ex);
        }
        return " ";

    }

}
